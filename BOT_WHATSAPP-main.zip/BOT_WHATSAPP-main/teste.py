import gspread
from oauth2client.service_account import ServiceAccountCredentials

print("🔍 Testando arquivo credentials.json...")

try:
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
    client = gspread.authorize(creds)
    
    # Tenta abrir a planilha
    sheet = client.open("Estoque")
    print("✅ SUCESSO! Conexão estabelecida.")
    print(f"Planilha encontrada: {sheet.title}")

except Exception as e:
    print("\n❌ FALHA CRÍTICA:")
    print(e)
    print("\nDICA: Verifique se o campo 'private_key' no JSON contém quebras de linha reais em vez de '\\n'.")
import os
import json
import gspread
import requests
import unicodedata
import redis
from datetime import datetime
from collections import defaultdict
from oauth2client.service_account import ServiceAccountCredentials
from dotenv import load_dotenv
from database import salvar_cliente

load_dotenv()

# --- AUXILIAR DE LOG ---
def log(emoji, categoria, mensagem):
    hora = datetime.now().strftime("%H:%M:%S")
    try:
        print(f"{hora} {emoji} [{categoria:<10}] {mensagem}")
    except:
        print(f"{hora} {emoji} [{categoria}] {mensagem}")

# --- CONFIGURAÇÕES ---
API_URL = os.getenv("SERVER_URL", "http://evolution-api:8080")
INSTANCE = "tes"
API_KEY = os.getenv("EVOLUTION_API_KEY") 
NUMERO_GERENTE = "595992091456" 

STORE_LAT = "-23.586145"
STORE_LON = "-46.763428"
PRECO_POR_KM = 1.00
TAXA_BASE = 15.00

redis_client = redis.Redis(host='evolution_redis', port=6379, db=0, decode_responses=True)

# --- GOOGLE SHEETS ---
def get_spreadsheet():
    try:
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
        client = gspread.authorize(creds)
        return client.open("Estoque")
    except Exception as e:
        log("❌", "PLANILHA", f"Erro ao conectar: {e}")
        return None

# --- GEO & ROTA ---
def get_coordinates(address):
    try:
        headers = {'User-Agent': 'BotEntregaFF/1.0'}
        url = "https://nominatim.openstreetmap.org/search"
        params = {'q': address, 'format': 'json', 'limit': 1}
        response = requests.get(url, params=params, headers=headers)
        data = response.json()
        if data:
            return data[0]['lat'], data[0]['lon']
    except: pass
    return None, None

def get_driving_distance(lat1, lon1, lat2, lon2):
    try:
        url = f"http://router.project-osrm.org/route/v1/driving/{lon1},{lat1};{lon2},{lat2}?overview=false"
        response = requests.get(url)
        data = response.json()
        if data.get("routes"):
            return data["routes"][0]["distance"] / 1000 
    except: pass
    return 0.0

# --- FERRAMENTAS ---

def verificar_estoque(query: str):
    """
    Busca produtos.
    - Se a busca for genérica ('tudo', 'lista'), retorna TODO o estoque (155 itens) agrupado.
    - Se for específica, retorna todos os matches (sem limite de 5).
    """
    log("🔍", "TOOL", f"Verificando estoque para: '{query}'")
    sh = get_spreadsheet()
    if not sh: return json.dumps({"erro": "Erro planilha"})
    
    todos_produtos = []
    try:
        for worksheet in sh.worksheets():
            rows = worksheet.get_all_records()
            todos_produtos.extend(rows)
    except Exception as e:
        log("❌", "PLANILHA", f"Erro leitura abas: {e}")
        return json.dumps({"erro": "Erro leitura abas"})

    query = str(query).lower().strip()
    
    # Lista de termos que ativam o modo "MOSTRAR TUDO"
    termos_mostrar_tudo = ["tudo", "todos", "lista", "catalogo", "opções", "opcoes", "estoque", "ver", "quais", "geral"]
    
    # --- MODO MOSTRAR TUDO (LISTA COMPLETA) ---
    if any(t == query for t in termos_mostrar_tudo) or query == "" or query == "o que tem":
        
        # Agrupa por Categoria para ficar organizado
        estoque_agrupado = defaultdict(list)
        total_itens = 0
        
        for row in todos_produtos:
            nome = str(row.get('Nome', ''))
            cat = str(row.get('Categorias', 'Geral'))
            preco = str(row.get('Preço', '0'))
            
            # Formata: "Amortecedor Focus (R$ 240.00)"
            item_str = f"- {nome} ({preco})"
            
            # Limpa a categoria (pega só a marca ou o tipo principal)
            if ">" in cat:
                grupo = cat.split(">")[-1].strip() # Ex: Ford
            else:
                grupo = cat
            
            estoque_agrupado[grupo].append(item_str)
            total_itens += 1
            
        # Monta o textão
        relatorio = f"📦 **ESTOQUE COMPLETO ({total_itens} itens):**\n"
        
        for grupo, itens in sorted(estoque_agrupado.items()):
            relatorio += f"\n📂 **{grupo.upper()}**\n"
            relatorio += "\n".join(itens) # Lista todos os itens daquele grupo
            
        return json.dumps({"relatorio_completo": relatorio[:4000], "aviso": "Se a lista for muito grande, o WhatsApp pode cortar. Mas aqui está o resumo."})

    # --- MODO BUSCA ESPECÍFICA (SEM LIMITE RÍGIDO) ---
    resultados = []
    stopwords = ["serve", "para", "no", "na", "o", "a", "meu", "carro", "veiculo", "essa", "esse", "tem", "gostaria", "preciso", "de", "da", "vende", "kit"]
    
    termos_brutos = query.split()
    termos_uteis = [t for t in termos_brutos if t not in stopwords and len(t) > 1] 
    if not termos_uteis: termos_uteis = termos_brutos # Se sobrar nada, usa o original

    for row in todos_produtos:
        id_prod = str(row.get('Identificador', ''))
        nome_prod = str(row.get('Nome', ''))
        categoria = str(row.get('Categorias', ''))
        preco = str(row.get('Preço', '0'))
        qtd_raw = row.get('Quantidade', 0)

        texto_linha = f"{nome_prod} {categoria} {id_prod}".lower()
        
        matches = 0
        for termo in termos_uteis:
            if termo in texto_linha: matches += 1
        
        # Se bater todos os termos úteis OU tiver pontuação alta
        score = matches / len(termos_uteis) if termos_uteis else 0
        
        if score >= 0.3 or matches >= 1:
            try: qtd = int(qtd_raw)
            except: qtd = 0
            
            if qtd > 0:
                resultados.append({
                    "produto": nome_prod,
                    "categoria": categoria,
                    "preco": f"R$ {preco}",
                    "estoque": qtd,
                    "id": id_prod
                })
    
    if not resultados:
        return json.dumps({"mensagem": "Não encontrei produtos com esses termos. Tente ser mais específico (ex: 'Amortecedor Palio')."})
    
    # Retorna TUDO o que achou (limite de segurança de 100 pra não explodir a API, mas cobre sua planilha toda)
    return json.dumps(resultados[:100])

def calcular_frete_mock(endereco_cliente: str):
    log("🚚", "TOOL", f"Calculando frete para: {endereco_cliente}")
    lat_dest, lon_dest = get_coordinates(endereco_cliente)
    if not lat_dest: return json.dumps({"erro": "Endereço não localizado. Tente enviar o CEP."})
    
    dist_km = get_driving_distance(STORE_LAT, STORE_LON, lat_dest, lon_dest)
    if dist_km == 0: return json.dumps({"erro": "Erro rota."})
    
    valor = TAXA_BASE + (dist_km * PRECO_POR_KM)
    
    return json.dumps({
        "distancia": f"{dist_km:.1f} km",
        "valor_frete": f"R$ {valor:.2f}",
        "prazo": "Entrega Imediata"
    })

def notificar_venda_gerente(nome_cliente: str, item_id: str, nome_produto: str, valor_total: str, pagamento: str):
    log("🚨", "TOOL", f"Notificando gerente ({NUMERO_GERENTE})...")
    redis_client.set("pending_product_id", str(item_id)) 
    msg = (
        f"🚨 *NOVA VENDA* 🚨\n"
        f"👤 {nome_cliente}\n🛠 {nome_produto} (ID: {item_id})\n💰 {valor_total}\n💳 {pagamento}\n"
        f"👉 *AGUARDANDO AÇÃO HUMANA*"
    )
    url = f"{API_URL}/message/sendText/{INSTANCE}"
    headers = {"apikey": API_KEY}
    try:
        requests.post(url, json={"number": NUMERO_GERENTE, "text": msg}, headers=headers)
    except: pass
    return json.dumps({"status": "GERENTE_ACIONADO"})

def finalizar_venda_estoque(product_id: str):
    log("📉", "TOOL", f"Procurando ID {product_id} em todas as abas...")
    sh = get_spreadsheet()
    if not sh: return "Erro Planilha"
    try:
        for worksheet in sh.worksheets():
            try:
                cell = worksheet.find(str(product_id))
                if cell:
                    headers = worksheet.row_values(1)
                    col_qtd = headers.index("Quantidade") + 1
                    val = int(worksheet.cell(cell.row, col_qtd).value)
                    worksheet.update_cell(cell.row, col_qtd, val - 1)
                    log("✅", "TOOL", f"Baixa efetuada em {worksheet.title}")
                    return f"Baixa efetuada"
            except: continue 
    except Exception as e:
        log("❌", "TOOL", f"Erro baixa: {e}")
    return "Produto não encontrado"

def registrar_nome_cliente(nome, remote_jid=None):
    if remote_jid: salvar_cliente(remote_jid, nome)
    return "Salvo"

import os
from sqlalchemy import create_engine, Column, String, MetaData, Table
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

# Conexão usando as variáveis do docker-compose
DATABASE_URL = "postgresql://evolution:senha_forte_pg@postgres:5432/evolution"

engine = create_engine(DATABASE_URL)
metadata = MetaData()

# Definição da Tabela de Clientes
clients_table = Table(
    'vmg_clientes', metadata,
    Column('telefone', String, primary_key=True),
    Column('nome', String, nullable=False)
)

# Cria a tabela se não existir
metadata.create_all(engine)

def get_cliente_nome(telefone):
    """Busca o nome pelo telefone"""
    try:
        with engine.connect() as conn:
            query = clients_table.select().where(clients_table.c.telefone == telefone)
            result = conn.execute(query).fetchone()
            if result:
                return result.nome
            return None
    except Exception as e:
        print(f"❌ Erro DB (Get): {e}")
        return None

def salvar_cliente(telefone, nome):
    """Salva ou atualiza o nome do cliente"""
    try:
        with engine.connect() as conn:
            delete_stmt = clients_table.delete().where(clients_table.c.telefone == telefone)
            conn.execute(delete_stmt)
            
            insert_stmt = clients_table.insert().values(telefone=telefone, nome=nome)
            conn.execute(insert_stmt)
            conn.commit()
            return True
    except Exception as e:
        print(f"❌ Erro DB (Save): {e}")
        return False

def deletar_cliente(telefone):
    """Remove um cliente do banco (Função essencial para o Reset)"""
    try:
        with engine.connect() as conn:
            delete_stmt = clients_table.delete().where(clients_table.c.telefone == telefone)
            conn.execute(delete_stmt)
            conn.commit()
            return True
    except Exception as e:
        print(f"❌ Erro DB (Delete): {e}")
        return False
import os
import asyncio
import redis
import requests
import json
import traceback
import time
from datetime import datetime
from fastapi import FastAPI, Request
from agno.agent import Agent
from agno.models.deepseek import DeepSeek
from agno.db.redis import RedisDb
from dotenv import load_dotenv
from database import get_cliente_nome, deletar_cliente, salvar_cliente
from agent_tools import (
    verificar_estoque, 
    calcular_frete_mock, 
    notificar_venda_gerente, 
    finalizar_venda_estoque, 
    registrar_nome_cliente
)

load_dotenv()

def log(emoji, categoria, mensagem):
    hora = datetime.now().strftime("%H:%M:%S")
    try: print(f"\033[92m{hora} {emoji} [{categoria:<10}] {mensagem}\033[0m")
    except: print(f"{hora} {emoji} [{categoria}] {mensagem}")

app = FastAPI()

EVOLUTION_URL = os.getenv("SERVER_URL", "http://evolution-api:8080")
EVOLUTION_API_KEY = os.getenv("EVOLUTION_API_KEY")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")

# Instância correta
INSTANCE_NAME = "tes"

BUFFER_DELAY = 2.0
TIMEOUT_HORAS = 2

redis_client = redis.Redis(host='evolution_redis', port=6379, db=0, decode_responses=True)
agent_storage = RedisDb(db_url="redis://evolution_redis:6379/1")

system_prompt = "Você é um vendedor."
try:
    with open("prompt.md", "r", encoding="utf-8") as f: system_prompt = f.read()
except: pass

active_timers = {}

def enviar_mensagem(number, text):
    if not number or not text: return
    clean_number = number.split("@")[0] if "@" in number else number
    url = f"{EVOLUTION_URL}/message/sendText/{INSTANCE_NAME}"
    headers = {"apikey": EVOLUTION_API_KEY}
    
    partes = text.split("\n\n") 
    for parte in partes:
        if not parte.strip(): continue
        try:
            log("📤", "WHATSAPP", f"Enviando para {clean_number}...")
            requests.post(url, json={"number": clean_number, "text": parte}, headers=headers)
            time.sleep(1) 
        except Exception as e: log("❌", "ERRO", f"Falha envio: {e}")

async def monitorar_inatividade():
    while True:
        try:
            keys = redis_client.keys("last_seen:*")
            agora = time.time()
            limit = TIMEOUT_HORAS * 3600
            for key in keys:
                jid = key.split(":")[1]
                try: last = float(redis_client.get(key))
                except: redis_client.delete(key); continue
                
                if (agora - last) > limit:
                    if not redis_client.get(f"status_pagamento:{jid}"):
                        redis_client.delete(key)
                        agent_storage.delete_session(jid)
                        enviar_mensagem(jid, "⏳ Olá! Vou encerrar por enquanto. Se precisar, chame!")
            await asyncio.sleep(60)
        except: await asyncio.sleep(60)

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(monitorar_inatividade())

async def processar_conversa(remote_jid):
    try:
        # Se já estiver esperando pagamento (Gerente), ignora o cliente
        if redis_client.get(f"status_pagamento:{remote_jid}"): return

        redis_key = f"buffer_msgs:{remote_jid}"
        messages = redis_client.lrange(redis_key, 0, -1)
        if not messages: return
        redis_client.delete(redis_key)
        
        nome = get_cliente_nome(remote_jid)
        full_text = "\n".join(messages) + f"\n[SISTEMA]: ID {remote_jid}. Contexto: {{'cliente_nome': '{nome or ''}'}}"
        
        log("🧠", "AGENTE", f"Pensando... ({nome})")

        current_agent = Agent(
            model=DeepSeek(id="deepseek-chat", api_key=DEEPSEEK_API_KEY, temperature=0.1, max_tokens=400),
            description="Vendedor",
            instructions=system_prompt, # Usa o prompt novo
            tools=[verificar_estoque, calcular_frete_mock, notificar_venda_gerente, finalizar_venda_estoque, registrar_nome_cliente],
            db=agent_storage,            
            add_history_to_context=True,
            session_id=remote_jid 
        )

        response = current_agent.run(full_text)
        
        bot_reply = ""
        if hasattr(response, 'content'): bot_reply = response.content
        elif hasattr(response, 'messages') and response.messages: bot_reply = response.messages[-1].content
        else: bot_reply = str(response)

        # --- LÓGICA DE PAUSA ATUALIZADA ---
        # Pausa se a ferramenta foi usada OU se ele falou a frase de "preparando"
        if "GERENTE_ACIONADO" in str(response) or "prepar" in bot_reply.lower() or "aguarde" in bot_reply.lower():
            log("⏸️", "AGENTE", "Pausando para processamento (Gerente acionado)")
            redis_client.set(f"status_pagamento:{remote_jid}", "true", ex=7200)

        if bot_reply.strip():
            enviar_mensagem(remote_jid, bot_reply)

    except Exception as e:
        log("❌", "CRÍTICO", str(e))
        traceback.print_exc()

async def agendar(remote_jid):
    await asyncio.sleep(BUFFER_DELAY)
    await processar_conversa(remote_jid)

def encontrar_jid(data):
    try:
        content = data
        if "data" in data: content = data["data"]
        if isinstance(content, list): content = content[0]
        key = content.get("key", {})
        msg = content.get("message", {})
        return key.get("remoteJid"), key.get("fromMe"), msg, key.get("id", "")
    except: return None, False, {}, ""

@app.post("/webhook")
@app.post("/webhook/messages-upsert")
async def webhook(request: Request):
    try:
        raw_data = await request.json()
        remote_jid, from_me, msg_obj, msg_id = encontrar_jid(raw_data)

        if not remote_jid: return {"status": "no_jid"}
        text = msg_obj.get("conversation") or msg_obj.get("extendedTextMessage", {}).get("text") or ""
        if not text: return {"status": "no_text"}

        if not from_me: redis_client.set(f"last_seen:{remote_jid}", time.time())

        # --- GERENTE ---
        if from_me:
            if "tudo certinho" in text.lower() and "obrigado" in text.lower():
                log("🎯", "GERENTE", "Finalizando venda.")
                
                prod_id = redis_client.get("pending_product_id")
                if prod_id: 
                    finalizar_venda_estoque(prod_id)
                    redis_client.delete("pending_product_id")
                
                redis_client.delete(f"status_pagamento:{remote_jid}")
                agent_storage.delete_session(remote_jid)
            return {"status": "manager"}

        # --- CLIENTE ---
        if text.strip() == "#reset":
            deletar_cliente(remote_jid)
            agent_storage.delete_session(remote_jid)
            redis_client.delete(f"status_pagamento:{remote_jid}")
            enviar_mensagem(remote_jid, "🧹 Resetado.")
            return {"status": "reset"}

        redis_key = f"buffer_msgs:{remote_jid}"
        redis_client.rpush(redis_key, text)
        redis_client.expire(redis_key, 3600)
        
        if remote_jid in active_timers: active_timers[remote_jid].cancel()
        active_timers[remote_jid] = asyncio.create_task(agendar(remote_jid))

    except: pass
    return {"status": "ok"}
document.addEventListener('DOMContentLoaded', () => {
    const paymentSection = document.getElementById('payment');
    paymentSection.classList.add('hidden');
    const platformCards = document.querySelectorAll('.platform-card');
    const pricingOptions = document.getElementById('pricing-options');
    const optionsContainer = document.querySelector('.options-container');
    const userForm = document.getElementById('user-form');
    const modal = document.getElementById('confirmation-modal');
    const closeModalBtn = document.querySelector('.close-btn');
    const goHomeBtn = document.getElementById('go-home-btn');
    const copyBtns = document.querySelectorAll('.copy-btn');

    let selectedPlatform = null;
    let selectedDuration = null;
    let selectedPrice = null;

    const pricingData = {
        Netflix: [
            { duration: '3 months', price: 10 },
            { duration: '6 months', price: 18 },
            { duration: '1 year', price: 30 }
        ],
        Prime: [
            { duration: '3 months', price: 3 },
            { duration: '6 months', price: 6 },
            { duration: '1 year', price: 10 }
        ],
        HBO: [
            { duration: '3 months', price: 6 },
            { duration: '6 months', price: 10 },
            { duration: '1 year', price: 20 }
        ]
    };

    platformCards.forEach(card => {
        card.addEventListener('click', () => {
            platformCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            selectedPlatform = card.dataset.platform;
            displayPricing(selectedPlatform);
        });
    });

    function displayPricing(platform) {
        optionsContainer.innerHTML = '';
        pricingData[platform].forEach(option => {
            const optionEl = document.createElement('div');
            optionEl.classList.add('price-option');
            optionEl.dataset.duration = option.duration;
            optionEl.dataset.price = option.price;
            optionEl.innerHTML = `${option.duration} - <span>$${option.price}</span>`;
            optionsContainer.appendChild(optionEl);
        });

        pricingOptions.classList.remove('hidden');
        paymentSection.classList.add('hidden');
        addPriceOptionListeners();
    }

    function addPriceOptionListeners() {
        const priceOptionDivs = document.querySelectorAll('.price-option');
        priceOptionDivs.forEach(option => {
            option.addEventListener('click', () => {
                priceOptionDivs.forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');
                selectedDuration = option.dataset.duration;
                selectedPrice = option.dataset.price;
                paymentSection.classList.remove('hidden');
                paymentSection.scrollIntoView({ behavior: 'smooth' });
            });
        });
    }

    copyBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const input = btn.previousElementSibling;
            input.select();
            document.execCommand('copy');
            btn.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                btn.innerHTML = '<i class="fas fa-copy"></i>';
            }, 2000);
        });
    });

    userForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const transactionHash = document.getElementById('transaction-hash').value;

        const orderDetails = {
            platform: selectedPlatform,
            duration: selectedDuration,
            price: selectedPrice,
            email: email,
            transactionHash: transactionHash
        };

        // Replace with your Telegram Bot details
        const telegramBotToken = '5124364308:AAH1Wq3mc15nYSG_NMUgUcz26CjTNE6KN6E';
        const telegramChatId = '1890681503';
        const message = `
New Order:
Platform: ${orderDetails.platform}
Duration: ${orderDetails.duration}
Price: $${orderDetails.price}
Email: ${orderDetails.email}
Transaction Hash: ${orderDetails.transactionHash}
        `;

        try {
           await fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    chat_id: telegramChatId,
                    text: message
                })
            });
        } catch (error) {
            console.error('Error sending message to Telegram:', error);
        }

        modal.classList.remove('hidden');
    });

    closeModalBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
    });

    goHomeBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    document.querySelector('.scroll-down-btn').addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

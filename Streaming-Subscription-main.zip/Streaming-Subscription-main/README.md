# Streaming-Subscription
🚀 This is a sleek, animated website for selling digital streaming subscriptions like Netflix, Prime Video, and HBO Max. 🎬 Users can select a plan 📦, pay using USDT, ETH, or BTC 💰, and submit their email 📧 and transaction hash 🔗. Orders are instantly sent to the admin via Telegram Bot 🤖 for fast delivery ⚡.

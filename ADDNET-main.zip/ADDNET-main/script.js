const inputText = document.getElementById('input-text');
const formatBtn = document.getElementById('format-btn');
const outputText = document.getElementById('output-text');

formatBtn.addEventListener('click', () => {
    const lines = inputText.value.split('\n');
    let output = '';

    lines.forEach(line => {
        if (line.trim() === '') {
            return;
        }

        const emailMatch = line.match(/([^:]+:[^:]+):/);
        const countryMatch = line.match(/Country = ([^ |]+)/);
        const phoneMatch = line.match(/phonenumber = ([^ |]+)/);

        if (emailMatch && countryMatch) {
            const emailPassword = emailMatch[1];
            const country = countryMatch[1];

            // A simple mapping for country codes to full names
            const countryMap = {
                "US": "USA",
                "CA": "Canada",
                "GB": "United Kingdom"
                // Add more mappings as needed
            };

            const countryFullName = countryMap[country.toUpperCase()] || country;

            if (phoneMatch) {
                const phone = phoneMatch[1];
                output += `/add_netflix ${emailPassword}:${phone}:${countryFullName}\n`;
            } else {
                output += `'${emailPassword} is NO PHONE NUMBER'\n`;
            }
        }
    });

    outputText.value = output;
});
